package br.com.kadus.estoquesuggar.dao;

import br.com.kadus.estoquesuggar.model.Movimentacao;
import br.com.kadus.estoquesuggar.util.Conexao;
import java.sql.*;

/** DAO responsável pelo histórico de movimentações. */
public class MovimentacaoDAO {

    public void registrar(Movimentacao m) throws SQLException {
        String sql = "INSERT INTO movimentacao " +
                     "(produto_id,tipo,quantidade,observacao) VALUES (?,?,?,?)";

        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setInt(1, m.getProdutoId());
            s.setString(2, m.getTipo());
            s.setInt(3, m.getQuantidade());
            s.setString(4, m.getObservacao());
            s.executeUpdate();
        }
    }

    public String historico() throws SQLException {
        String sql = "SELECT m.id,p.codigo,p.nome,m.tipo,m.quantidade," +
                     "m.data_movimentacao,m.observacao " +
                     "FROM movimentacao m JOIN produto p ON p.id=m.produto_id " +
                     "ORDER BY m.data_movimentacao DESC";

        StringBuilder b = new StringBuilder();

        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql);
             ResultSet r = s.executeQuery()) {
            while (r.next()) {
                b.append("ID ").append(r.getInt("id"))
                 .append(" | ").append(r.getString("tipo"))
                 .append(" | ").append(r.getString("codigo"))
                 .append(" | Qtd: ").append(r.getInt("quantidade"))
                 .append(" | ").append(r.getTimestamp("data_movimentacao"))
                 .append(" | ").append(r.getString("observacao"))
                 .append("\n");
            }
        }
        return b.length() == 0 ? "Nenhuma movimentação registrada." : b.toString();
    }
}
