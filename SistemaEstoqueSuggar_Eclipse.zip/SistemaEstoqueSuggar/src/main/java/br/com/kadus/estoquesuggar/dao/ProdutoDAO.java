package br.com.kadus.estoquesuggar.dao;

import br.com.kadus.estoquesuggar.model.Produto;
import br.com.kadus.estoquesuggar.util.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** DAO: concentra os comandos SQL relacionados a Produto. */
public class ProdutoDAO {

    public void cadastrar(Produto p) throws SQLException {
        String sql = "INSERT INTO produto " +
            "(codigo,nome,categoria,cor,voltagem,capacidade,quantidade_estoque,estoque_minimo) " +
            "VALUES (?,?,?,?,?,?,?,?)";

        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, p.getCodigo());
            s.setString(2, p.getNome());
            s.setString(3, p.getCategoria());
            s.setString(4, p.getCor());
            s.setString(5, p.getVoltagem());
            s.setString(6, p.getCapacidade());
            s.setInt(7, p.getQuantidadeEstoque());
            s.setInt(8, p.getEstoqueMinimo());
            s.executeUpdate();
        }
    }

    public List<Produto> listarTodos() throws SQLException {
        List<Produto> lista = new ArrayList<>();
        String sql = "SELECT * FROM produto ORDER BY categoria,nome";

        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql);
             ResultSet r = s.executeQuery()) {
            while (r.next()) lista.add(mapear(r));
        }
        return lista;
    }

    public Produto buscarPorCodigo(String codigo) throws SQLException {
        String sql = "SELECT * FROM produto WHERE codigo=?";
        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, codigo);
            try (ResultSet r = s.executeQuery()) {
                if (r.next()) return mapear(r);
            }
        }
        return null;
    }

    public void atualizarEstoque(int id, int quantidade) throws SQLException {
        String sql = "UPDATE produto SET quantidade_estoque=? WHERE id=?";
        try (Connection c = Conexao.conectar();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setInt(1, quantidade);
            s.setInt(2, id);
            s.executeUpdate();
        }
    }

    private Produto mapear(ResultSet r) throws SQLException {
        Produto p = new Produto();
        p.setId(r.getInt("id"));
        p.setCodigo(r.getString("codigo"));
        p.setNome(r.getString("nome"));
        p.setCategoria(r.getString("categoria"));
        p.setCor(r.getString("cor"));
        p.setVoltagem(r.getString("voltagem"));
        p.setCapacidade(r.getString("capacidade"));
        p.setQuantidadeEstoque(r.getInt("quantidade_estoque"));
        p.setEstoqueMinimo(r.getInt("estoque_minimo"));
        return p;
    }
}
