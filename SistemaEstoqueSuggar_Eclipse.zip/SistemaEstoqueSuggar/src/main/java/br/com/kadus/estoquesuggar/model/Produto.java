package br.com.kadus.estoquesuggar.model;

/** Entidade que representa um produto do estoque. */
public class Produto {
    private int id;
    private String codigo, nome, categoria, cor, voltagem, capacidade;
    private int quantidadeEstoque, estoqueMinimo;

    public Produto() {}

    public Produto(String codigo, String nome, String categoria, String cor,
                   String voltagem, String capacidade, int quantidadeEstoque,
                   int estoqueMinimo) {
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = categoria;
        this.cor = cor;
        this.voltagem = voltagem;
        this.capacidade = capacidade;
        this.quantidadeEstoque = quantidadeEstoque;
        this.estoqueMinimo = estoqueMinimo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public String getCor() { return cor; }
    public String getVoltagem() { return voltagem; }
    public String getCapacidade() { return capacidade; }
    public int getQuantidadeEstoque() { return quantidadeEstoque; }
    public int getEstoqueMinimo() { return estoqueMinimo; }

    public void setCodigo(String codigo) { this.codigo = codigo; }
    public void setNome(String nome) { this.nome = nome; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setCor(String cor) { this.cor = cor; }
    public void setVoltagem(String voltagem) { this.voltagem = voltagem; }
    public void setCapacidade(String capacidade) { this.capacidade = capacidade; }
    public void setQuantidadeEstoque(int quantidadeEstoque) { this.quantidadeEstoque = quantidadeEstoque; }
    public void setEstoqueMinimo(int estoqueMinimo) { this.estoqueMinimo = estoqueMinimo; }
}
