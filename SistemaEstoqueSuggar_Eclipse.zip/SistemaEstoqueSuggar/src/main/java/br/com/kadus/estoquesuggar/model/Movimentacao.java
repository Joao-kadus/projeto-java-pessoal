package br.com.kadus.estoquesuggar.model;

/** Representa uma entrada ou saída de estoque. */
public class Movimentacao {
    private int produtoId;
    private String tipo;
    private int quantidade;
    private String observacao;

    public Movimentacao(int produtoId, String tipo, int quantidade, String observacao) {
        this.produtoId = produtoId;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.observacao = observacao;
    }

    public int getProdutoId() { return produtoId; }
    public String getTipo() { return tipo; }
    public int getQuantidade() { return quantidade; }
    public String getObservacao() { return observacao; }
}
