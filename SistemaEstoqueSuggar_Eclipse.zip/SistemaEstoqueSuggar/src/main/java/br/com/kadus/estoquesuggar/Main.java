package br.com.kadus.estoquesuggar;

import br.com.kadus.estoquesuggar.dao.MovimentacaoDAO;
import br.com.kadus.estoquesuggar.dao.ProdutoDAO;
import br.com.kadus.estoquesuggar.model.Movimentacao;
import br.com.kadus.estoquesuggar.model.Produto;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.util.List;

/**
 * Classe principal.
 * A interface usa JOptionPane, uma forma simples de criar
 * caixas de diálogo em Java/Swing.
 */
public class Main {

    private static final ProdutoDAO produtoDAO = new ProdutoDAO();
    private static final MovimentacaoDAO movimentacaoDAO = new MovimentacaoDAO();

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            String menu =
                "SISTEMA DE ESTOQUE - SUGGAR\n\n" +
                "1 - Cadastrar produto\n" +
                "2 - Listar produtos\n" +
                "3 - Buscar produto\n" +
                "4 - Registrar entrada\n" +
                "5 - Registrar saída\n" +
                "6 - Ver histórico\n" +
                "7 - Ver estoque baixo\n" +
                "0 - Sair\n\nDigite uma opção:";

            String entrada = JOptionPane.showInputDialog(menu);
            if (entrada == null) break;

            try {
                opcao = Integer.parseInt(entrada);

                switch (opcao) {
                    case 1 -> cadastrar();
                    case 2 -> listar();
                    case 3 -> buscar();
                    case 4 -> movimentar("ENTRADA");
                    case 5 -> movimentar("SAIDA");
                    case 6 -> historico();
                    case 7 -> estoqueBaixo();
                    case 0 -> JOptionPane.showMessageDialog(null, "Sistema encerrado.");
                    default -> JOptionPane.showMessageDialog(null, "Opção inválida.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Digite somente números.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                    "Erro no banco:\n" + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void cadastrar() throws SQLException {
        String codigo = JOptionPane.showInputDialog("Código:");
        if (codigo == null) return;

        String nome = JOptionPane.showInputDialog("Nome/modelo:");
        if (nome == null) return;

        String categoria = JOptionPane.showInputDialog("Categoria:");
        if (categoria == null) return;

        String cor = JOptionPane.showInputDialog("Cor:");
        if (cor == null) return;

        String voltagem = JOptionPane.showInputDialog("Voltagem:");
        if (voltagem == null) return;

        String capacidade = JOptionPane.showInputDialog("Capacidade/tamanho:");
        if (capacidade == null) return;

        int qtd = inteiro("Quantidade inicial:");
        int minimo = inteiro("Estoque mínimo:");

        if (qtd < 0 || minimo < 0) return;

        produtoDAO.cadastrar(new Produto(
            codigo, nome, categoria, cor, voltagem,
            capacidade, qtd, minimo
        ));

        JOptionPane.showMessageDialog(null, "Produto cadastrado!");
    }

    private static void listar() throws SQLException {
        List<Produto> produtos = produtoDAO.listarTodos();

        if (produtos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum produto cadastrado.");
            return;
        }

        StringBuilder b = new StringBuilder("PRODUTOS\n\n");
        for (Produto p : produtos) {
            b.append(p.getCodigo()).append(" | ")
             .append(p.getNome()).append(" | ")
             .append(p.getCategoria()).append(" | Estoque: ")
             .append(p.getQuantidadeEstoque()).append("\n");
        }

        JOptionPane.showMessageDialog(null, b.toString());
    }

    private static void buscar() throws SQLException {
        String codigo = JOptionPane.showInputDialog("Código do produto:");
        if (codigo == null) return;

        Produto p = produtoDAO.buscarPorCodigo(codigo);

        if (p == null) {
            JOptionPane.showMessageDialog(null, "Produto não encontrado.");
            return;
        }

        String texto =
            "PRODUTO ENCONTRADO\n\n" +
            "Código: " + p.getCodigo() + "\n" +
            "Nome: " + p.getNome() + "\n" +
            "Categoria: " + p.getCategoria() + "\n" +
            "Cor: " + p.getCor() + "\n" +
            "Voltagem: " + p.getVoltagem() + "\n" +
            "Capacidade: " + p.getCapacidade() + "\n" +
            "Estoque: " + p.getQuantidadeEstoque() + "\n" +
            "Mínimo: " + p.getEstoqueMinimo();

        JOptionPane.showMessageDialog(null, texto);
    }

    private static void movimentar(String tipo) throws SQLException {
        String codigo = JOptionPane.showInputDialog("Código do produto:");
        if (codigo == null) return;

        Produto p = produtoDAO.buscarPorCodigo(codigo);

        if (p == null) {
            JOptionPane.showMessageDialog(null, "Produto não encontrado.");
            return;
        }

        int qtd = inteiro("Quantidade:");
        if (qtd <= 0) {
            JOptionPane.showMessageDialog(null, "Quantidade inválida.");
            return;
        }

        int novoEstoque;

        if (tipo.equals("ENTRADA")) {
            novoEstoque = p.getQuantidadeEstoque() + qtd;
        } else {
            if (qtd > p.getQuantidadeEstoque()) {
                JOptionPane.showMessageDialog(null, "Estoque insuficiente.");
                return;
            }
            novoEstoque = p.getQuantidadeEstoque() - qtd;
        }

        String obs = JOptionPane.showInputDialog("Observação:");
        if (obs == null) obs = "";

        produtoDAO.atualizarEstoque(p.getId(), novoEstoque);
        movimentacaoDAO.registrar(
            new Movimentacao(p.getId(), tipo, qtd, obs)
        );

        JOptionPane.showMessageDialog(null,
            "Movimentação registrada.\nEstoque atual: " + novoEstoque);
    }

    private static void historico() throws SQLException {
        JOptionPane.showMessageDialog(null, movimentacaoDAO.historico());
    }

    private static void estoqueBaixo() throws SQLException {
        StringBuilder b = new StringBuilder("ESTOQUE BAIXO\n\n");
        boolean encontrou = false;

        for (Produto p : produtoDAO.listarTodos()) {
            if (p.getQuantidadeEstoque() <= p.getEstoqueMinimo()) {
                encontrou = true;
                b.append(p.getCodigo()).append(" - ")
                 .append(p.getNome()).append(" | Estoque: ")
                 .append(p.getQuantidadeEstoque()).append(" | Mínimo: ")
                 .append(p.getEstoqueMinimo()).append("\n");
            }
        }

        if (!encontrou) b.append("Nenhum produto com estoque baixo.");
        JOptionPane.showMessageDialog(null, b.toString());
    }

    private static int inteiro(String mensagem) {
        while (true) {
            String valor = JOptionPane.showInputDialog(mensagem);
            if (valor == null) return -1;

            try {
                return Integer.parseInt(valor);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Digite um número inteiro válido.");
            }
        }
    }
}
