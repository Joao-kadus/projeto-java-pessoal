# Sistema de Gerenciamento de Estoque — Suggar

Projeto pessoal/acadêmico desenvolvido em Java para praticar POO, JDBC, SQL e organização de um sistema de estoque.

## Tecnologias
- Java 17
- Eclipse
- Maven
- MySQL
- JDBC
- JOptionPane

## Funcionalidades
- Cadastro de produtos
- Listagem e busca
- Entrada de estoque
- Saída de estoque
- Histórico de movimentações
- Alerta de estoque baixo
- Persistência em MySQL

## Como executar
1. Instale JDK 17 ou superior.
2. Instale MySQL.
3. Execute `database/schema.sql`.
4. No Eclipse, importe o projeto como Maven Project.
5. Abra `Conexao.java` e coloque seu usuário/senha do MySQL.
6. Aguarde o Maven baixar o MySQL Connector/J.
7. Execute `Main.java`.

Os produtos iniciais são exemplos baseados no catálogo público da Suggar e devem ser conferidos no catálogo atual antes de qualquer uso operacional.
