CREATE DATABASE IF NOT EXISTS estoque_suggar;
USE estoque_suggar;

CREATE TABLE produto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(30) NOT NULL UNIQUE,
    nome VARCHAR(120) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    cor VARCHAR(40),
    voltagem VARCHAR(20),
    capacidade VARCHAR(40),
    quantidade_estoque INT NOT NULL DEFAULT 0,
    estoque_minimo INT NOT NULL DEFAULT 5
);

CREATE TABLE movimentacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    tipo ENUM('ENTRADA','SAIDA') NOT NULL,
    quantidade INT NOT NULL,
    data_movimentacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observacao VARCHAR(255),
    FOREIGN KEY (produto_id) REFERENCES produto(id)
);

INSERT INTO produto
(codigo,nome,categoria,cor,voltagem,capacidade,quantidade_estoque,estoque_minimo)
VALUES
('LAV-NEO-8','Neo Turbilhão 8 kg','Lavadora','Branca','127/220V','8 kg',12,5),
('LAV-LAVAMAX-10','Lavamax Eco 10 kg','Lavadora','Branca','127/220V','10 kg',8,5),
('LAV-LAVAMAX-15','Lavamax Eco 15 kg','Lavadora','Branca','127/220V','15 kg',6,4),
('LAV-LAVAMATIC-16','Lavamatic 16 kg','Lavadora','Branca','127/220V','16 kg',4,5),
('FOG-COOKGLASS-4','Cook Glass 4 queimadores','Fogão','Preto','Bivolt','4 queimadores',10,5),
('FOG-MAXGLASS-4','Max Glass 4 queimadores','Fogão','Preto','Bivolt','4 queimadores',7,5),
('FOG-BESTGLASS-4','Best Glass 4 queimadores','Fogão','Preto','Bivolt','4 queimadores',3,5),
('FOG-BESTGLASS-5','Best Glass 5 queimadores','Fogão','Preto','Bivolt','5 queimadores',5,4);
